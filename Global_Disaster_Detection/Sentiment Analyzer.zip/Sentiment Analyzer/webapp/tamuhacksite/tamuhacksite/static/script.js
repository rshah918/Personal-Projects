let result = document.getElementById('businessAnalysis');
let submit = document.getElementById('dataSubmit');
let businessName = document.getElementById('businessSearch');
let cityName = document.getElementById('citySearch');
let positive = document.getElementById('positiveTweet');
let negative = document.getElementById('negativeTweet');



function fetchApproval() {
  $.ajax({
    url: "/poll/",
    type: "POST",
    cache: false,
    data: {
        business: businessName.value,    //business
        location: cityName.value,   //location
    },
    success: function(response){
      //alert("test: " + response.match[1]);
      displayResult(response.match[0], response.match[1]);
      displayTweet(response.match[2], response.match[3]);


    }
  });

}
submit.addEventListener('click', fetchApproval);


function displayResult(avgRate, medRate){

  let avgToPercent = Math.round(((avgRate) * 100) * 100) / 100;
  let medToPercent = Math.round(((medRate) * 100) * 100) / 100;

  result.innerHTML = "In " + cityName.value + ", average public sentiment towards " +
  businessName.value + " is " + avgToPercent
    + "% positive. <br>";

  result.innerHTML += "Median sentiment value is " + medToPercent + "% positive.<br>";
}

function displayTweet(highestTweet, lowestTweet){
  positive.innerHTML =  "<br>" + highestTweet + "<br>";
  negative.innerHTML =  "<br>" + lowestTweet + "<br>";
}
