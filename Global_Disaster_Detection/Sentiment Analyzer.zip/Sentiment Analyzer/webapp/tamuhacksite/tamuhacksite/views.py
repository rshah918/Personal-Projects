from django.http import JsonResponse
from django.shortcuts import render
#Importing libraries
import sys
import os
import jsonpickle
import tweepy
import csv
from textblob import TextBlob
from git import Repo
import statistics

def get_match(business, location):

    keyphrase = business.split(' ')
    business = ''
    for word in keyphrase:
        business = business + word
        if keyphrase.index(word) < (len(keyphrase) - 1) and business != '':
            business = business + " AND "
    print(business)

    consumer_key = 'VBo9qa8ftO61mhSaYxHd6XHSn'
    consumer_secret = '9IqWfyO8TPeo4xj8fSaKMsJji5LbQh6JZWvOBbNpxvPLDFTOem'
    access_token = '2828468661-MRhcCGtBTOiBiRJlL0x4q6torL1WMm6leZjuaVH'
    access_secret = '7SgCleNBDZfWPGQNmKlmWNF2DX3wXaYFCVJ2JCdtqUiR9'

    #Pass our consumer key and consumer secret to Tweepy's user authentication handler
    auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
    #Pass our access token and access secret to Tweepy's user authentication handler
    auth.set_access_token(access_token, access_secret)
    #Creating a twitter API wrapper using tweepy
    #Details here http://docs.tweepy.org/en/v3.5.0/api.html
    api = tweepy.API(auth)
    #Error handling
    if (not api):
        print ("Problem connecting to API")

    #Getting Geo ID
    places = api.geo_search(query=location, granularity='city')

    #Copy id
    place_id = places[0].id

    #Switching to application authentication
    auth = tweepy.AppAuthHandler(consumer_key, consumer_secret)

    #Setting up new api wrapper, using authentication only
    api = tweepy.API(auth, wait_on_rate_limit=True,wait_on_rate_limit_notify=True)

    #Error handling
    if (not api):
        print ("Problem Connecting to API")

    searchQuery = 'place:' + place_id + ' ' + business
    #Maximum number of tweets we want to collect
    maxTweets = 100
    #The twitter Search API allows up to 100 tweets per query
    tweetsPerQry = 100

    tweetCount = 0
    csvFile = open('result.csv', 'w')
    csvWriter = csv.writer(csvFile)
    #Open a text file to save the tweets to

    with open('CollectedTweets.json', 'w') as f:

        #Tell the Cursor method that we want to use the Search API (api.search)
        #Also tell Cursor our query, and the maximum number of tweets to return
        average = 0
        sentiments = []
        payload = []
        max_sen = 0.00
        best_tweet = ''
        worst_tweet = ''
        min_sen = 1.00
        pos_sent_count = 0
        for tweet in tweepy.Cursor(api.search,q=searchQuery).items(maxTweets) :

            analysis = TextBlob(tweet.text)
            print(analysis)
            '''if analysis.sentiment[0]>0:
                print('Positive')
                sentiment = 'Positive'

            elif analysis.sentiment[0]<0:
                print('Negative')
                sentiment = 'Negative'
            else:
                print('Neutral')
                sentiment = 'Neutral'''
            if (analysis.sentiment[0] + analysis.sentiment[1] + 1)/2 >= 0.5:
                pos_sent_count = pos_sent_count + 1
            #Write the JSON format to the text file, and add one to the number of tweets we've collected
            f.write(jsonpickle.encode(tweet._json, unpicklable=False) + '\n')
            csvWriter.writerow([tweet.created_at, tweet.text, tweet.place.country, tweet.place.name, tweet.retweet_count, tweet.favorite_count, (analysis.sentiment[0] + 1)/2])
            average += (analysis.sentiment[0] + analysis.sentiment[1] + 1)/2
            tweetCount += 1
            sentiments.append((analysis.sentiment[0] + analysis.sentiment[1] + 1)/2)
            if (analysis.sentiment[0] + analysis.sentiment[1] + 1)/2 > max_sen:
                max_sen = (analysis.sentiment[0] + analysis.sentiment[1] + 1)/2
                best_tweet = tweet.text
            if (analysis.sentiment[0] + analysis.sentiment[1] + 1)/2 <= min_sen:
                min_sen = (analysis.sentiment[0] + analysis.sentiment[1] + 1)/2
                worst_tweet = tweet.text

        try:
            average = average/tweetCount
        except:
            average = 0.5
        #Display how many tweets we have collected
        print("Downloaded {0} tweets".format(tweetCount))

    payload.append(average)
    payload.append(statistics.median(sentiments)) #median value
    payload.append(best_tweet)
    payload.append(worst_tweet)
    payload = payload + list(reversed(sentiments))

    return payload

# ...
def indexView(request):
    return render(request, 'tamuhacksite/index.html')

def myView(request):
    business = request.POST.get("business", "")
    location = request.POST.get("location", "")
    match = get_match(business, location)

    return JsonResponse({
        "match": match
    })
